class DemoController < ApplicationController
  def index
  end
end
