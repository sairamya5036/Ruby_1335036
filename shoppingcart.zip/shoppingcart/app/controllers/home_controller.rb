class HomeController < ApplicationController
  def admin
  end

  def customer
  @categories=Category.all
  end
  
  def display
  @categories=Category.find(params[:id])
  @products=@categories.products
  end
end
