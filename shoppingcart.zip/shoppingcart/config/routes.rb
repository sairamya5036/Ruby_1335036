Rails.application.routes.draw do
  get 'home/display'

  get 'home/display'
  root to: 'home#customer'  
  get '/admin' => 'home#admin'
  get 'home/admin'

  get 'home/customer'
  get 'home/welcome'


  get 'diplay/:id' => 'home#display', as: :display

  resources :products
  resources :categories
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
