

def play_pass(str, n)
	atoz= ('A'..'Z').to_a
	result = ""
	result1 = str.tr('A-Z',(atoz[n..25] << atoz[0...n]).flatten.join).tr('0-9',('0'..'9').to_a.reverse.join)
result1.each_char.with_index{ |c,i|
if i.even?
result << c.upcase
else
result << c.downcase
end
}
result.reverse

end
	

 p play_pass("WELCOME B999ACK",2)

